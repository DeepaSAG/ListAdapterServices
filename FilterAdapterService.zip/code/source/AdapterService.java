

// -----( IS Java Code Template v1.2
// -----( CREATED: 2013-10-10 20:07:05 IST
// -----( ON-HOST: MCMUN01.eur.ad.sag

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import com.wm.app.b2b.server.ServiceManager;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import com.wm.app.b2b.client.Context;
import com.wm.data.IData;
import com.wm.data.IDataCursor;
import com.wm.data.IDataFactory;
import com.wm.data.IDataUtil;
import com.wm.lang.ns.NSName;
import com.wm.lang.ns.NSNode;
import com.wm.lang.ns.NSType;
// --- <<IS-END-IMPORTS>> ---

public final class AdapterService

{
	// ---( internal utility methods )---

	final static AdapterService _instance = new AdapterService();

	static AdapterService _newInstance() { return new AdapterService(); }

	static AdapterService _cast(Object o) { return (AdapterService)o; }

	// ---( server methods )---




	public static final void FilterAdapterService (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(FilterAdapterService)>> ---
		// @sigtype java 3.5
		// [i] field:0:required PackageName
		// [i] field:0:required FolderName
		// [i] field:0:required ServiceType {"BatchInsert","BatchUpdate","CustomSQL","Delete","DynamicSQL","Insert","Select","StoredProcedure","StoredProcedureWithSignature","Update"}
		// [o] field:1:required Output
		IDataCursor pipelineCursor = pipeline.getCursor();
		String packageName = (String) IDataUtil.get(pipelineCursor, "PackageName");
		String folderName = (String) IDataUtil.get(pipelineCursor, "FolderName");
		String serviceTemplatetype = (String) IDataUtil.get(pipelineCursor, "ServiceType");
		
		Values output =new Values();
		Values serviceValues;
		
		try {
			List<String> folderList = getInterFaces(packageName, folderName);
			int j=1;
			for (String folder : folderList) {
				IData input = IDataFactory.create();
				IDataCursor cursor = input.getCursor();
				IDataUtil.put(cursor, "package", packageName);
				IDataUtil.put(cursor, "interface", folder);
				NSType [] nstypearray = new NSType[1];
				nstypearray[0]=NSType.create("service");
				IDataUtil.put(cursor, "filter", nstypearray);
				IData nodeListIData = null;
				nodeListIData = Service.doInvoke("wm.server.ns", "getNodes",input);
				IDataCursor nodeListCursor = nodeListIData.getCursor();
				nodeListCursor.first("nodes");
				NSNode[] nsNodes= (NSNode[])nodeListCursor.getValue();
				Values[] nodevalues = new Values[nsNodes.length];
				for(int i=0;i<nsNodes.length;i++){
					nodevalues[i]=nsNodes[i].getValues();
				}
				String serviceName;
				for (int i = 0; i < nodevalues.length; i++) {					
					String value = (String) nodevalues[i].getValue("svc_type");
					if(value.equals("AdapterService")){
						Values propertyvalues = nodevalues[i].getValues("IRTNODE_PROPERTIES");
						if(propertyvalues.getValue("serviceTemplateName").equals("com.wm.adapter.wmjdbc.services."+serviceTemplatetype)){
							serviceName = (String) nodevalues[i].getValue("node_nsName");
							serviceValues = new Values();
							serviceValues.put("ServiceName", serviceName);
							serviceValues.put("FolderName",folder);
							serviceValues.put("Other Properties",propertyvalues);
							output.put("Service"+j,serviceValues);
							j++;
						}
					}				
				}
			}
			IDataUtil.put( pipelineCursor, "Output", output);
			pipelineCursor.destroy();
		} catch (Exception e) {
			e.printStackTrace();
		}				
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	public static List<String> getInterFaces(String packageName, String folderName)
	  {
	    List<String> interfaceList = new ArrayList<String>();
	
	    if ((folderName != null) && (packageName != null)) {
	    	interfaceList.add(folderName);
	      getInterFaceList(interfaceList, packageName, folderName);
	    }
	    return interfaceList;
	  }
	
	  public static void getInterFaceList(List<String> paramList, String packageName, String folderName) {
	    try {
	      IData localIData1 = IDataFactory.create();
	      IDataCursor localIDataCursor1 = localIData1.getCursor();
	      if (folderName != null) {
	        IDataUtil.put(localIDataCursor1, "interface", folderName);
	      }
	      IDataUtil.put(localIDataCursor1, "package", packageName);
	      IData localIData2 = Service.doInvoke(NSName.create("wm.server.ns:getNodeList"), localIData1);
	      IDataCursor localIDataCursor2 = localIData2.getCursor();
	      IData[] arrayOfIData1 = IDataUtil.getIDataArray(localIDataCursor2, "nodeList");
	      if (arrayOfIData1 == null) {
	        return;
	      }
	      for (IData localIData3 : arrayOfIData1) {
	        IDataCursor localIDataCursor3 = localIData3.getCursor();
	        String str1 = IDataUtil.getString(localIDataCursor3, "node_nsName");
	        String str2 = IDataUtil.getString(localIDataCursor3, "node_type");
	        if (str2.equals("interface")) {
	          paramList.add(str1);
	          getInterFaceList(paramList, packageName, str1);
	        }
	      }
	    } catch (ServiceException localServiceException) {
	      localServiceException.printStackTrace();
	    } catch (Exception localException) {
	      localException.printStackTrace();
	    }
	  }
	// --- <<IS-END-SHARED>> ---
}

